package com.assignment2.operators;

import java.util.Arrays;

public class Questions {
    public static void displayValues(){
        int x = 10;
        float y = (float) 20.3;//f;
        double pi = 3.14785;
        System.out.println("x =" +x);
        System.out.println("y =" +y);
        System.out.println("pi =" +pi);
    }

    public static void displayBool()
    {
        boolean result ;
        int count = 5;
        result = !((count > 5) || (count <= 1)); // always false
        //result = !(count > 5) && !(count <= 1);
        System.out.println(result);
    }
    public static void main(String[] args) {

        //question 16
        //displayValues();

        // question 4
        //displayBool();

        //question 17 - boolean NOT operator
        //displayNot();

        //question 18 - print even numbers
        //displayEven();

        //question 19 - number divisible by 5
        //displayDiv5();

        //question 20 - sum of 1 to 100 - 5050
        //displaySum();

        //question 21 - display 1 12 123 1234 12345 123456 1234567
        //displaySequence();

        //question 22 - sort array
        //sortArray();

        //question 23 - check odd
        /*
        boolean result = checkOdd(52);
        System.out.println("number is odd " +result);
        */

        //question 24 - add first 10 odd integers - ans 25
        //addOdd();

        //question 25 - generate random number
        generateRand();
    }

    private static void generateRand() {
        int min = 1;
        int max = 100;
        int rand_num = (int) (Math.random() * (max-min+1) + min);
        System.out.println("random number between 1 - 100 =" +rand_num);
    }

    private static void addOdd() {
        int result = 0;
        for ( int i = 1; i<=10; i+=2 )
            result+= i;
        System.out.println("sum of first 10 odd integers = " +result);
    }

    private static boolean checkOdd(int num) {
        if ( num % 2 == 0)
            return false;
        else
            return true;
    }



    private static void sortArray() {
        int[] a = { 3, 4 , 5, 1, 10, 2};
        Arrays.sort(a);
        System.out.println("Least in the array a = " +a[0]);
        System.out.println("Greatest in the array a =" +a[a.length-1]);
    }

    private static void displaySequence() {
        for (int i = 1; i<=7; i++) {
            for (int j = 1; j <= i; j++)
                System.out.print(j);
            System.out.print(" ");
        }
    }

    private static void displaySum() {
        int sum = 0;
        int i = 1;
        while(i<=100) {
            sum = sum + i++;
        }
        System.out.println("sum of 1 to 100 =" +sum );
    }

    private static void displayDiv5() {
        for(int i=1; i<=100; i++){
            if(i%5 == 0)
                System.out.println("divisible by 5 " +i);
            else
                System.out.println(i);
        }
    }

    private static void displayEven() {
        for(int i=2; i<= 100; i+=2)
            System.out.println(i);
    }

    private static void displayNot() {
        boolean value = true;
        System.out.println("Value = " + !value );
    }
}
