package com.axone.devintest.chapter2;
/* Question 9 Assignment 1
public class Assignment1 {
    public Assignment1(){
        System.out.println("I'm doing my assignment");
    }

    public static void main(String[] args){
        System.out.println("I love doing my assignment");
    }
}*/

/* Question 11 Assignment 1
public class Assignment1{
    public void displayText(){
        System.out.println("Java programming is Fun!");
    }

    public void displayNumber(){
        System.out.println("10,20,30");
    }
}
*/

// Question 12 Assignment 1 - Print text in question
public class Assignment1{
    /** Main Method to print the special characters + @ * and # **/
    /* Definition of Main Method below
       printing of special characters + * @ and #
     */
    public static void main(String[] args){
        System.out.println("++++++");
        System.out.println("@@@@@@");
        System.out.println("******");
        System.out.println("######");
    }

}