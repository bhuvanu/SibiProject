package org.testing.bhuvan;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.lang3.SystemUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.Date;

public class MainClass {
    WebDriver driver;
    ExtentReports report;
    ExtentTest test;

    public String getReportsFilename(){

        Date date = new Date();
        String filename = date.toString().replaceAll(" ","-").replaceAll(":","-");
        return filename;

    }

    public void openBrowser(){
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
            driver.navigate().to("https://www.amazon.co.uk/");
            driver.manage().window().maximize();

    }

    public WebElement checkElement(String key){
        WebElement element = driver.findElement(By.xpath(key));
        if ( element == null)
           test.log(LogStatus.ERROR,"Test 2", "Element Missing");
        return element;
    }

    public void clickElement(String key){
        driver.findElement(By.xpath(key)).click();
    }

    public void hoverDropDown(String key){
        Actions action = new Actions(driver);
        action.moveToElement(checkElement(key)).perform();

    }

    public void selectDropDown(String key,String text){
        Select select = new Select(checkElement(key));
        select.selectByVisibleText(text);
    }

    public void closeBrowser(){
        driver.quit();
    }

}
