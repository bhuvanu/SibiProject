package org.testing.bhuvan;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.commons.lang3.SystemUtils;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestClass extends MainClass {

    // Setup Reports file name and launch the browser
    @BeforeTest
    public void prepare(){
        report = new ExtentReports(SystemUtils.getUserDir()+"\\target\\Reports\\"+getReportsFilename()+".html");
       // test = report.startTest("Launching Browser");
        openBrowser();
    }

    //Test 1 - Verify the home page of Amazon.co.uk is displayed
    @Test(priority = 1)
    public void verifyHomePage(){
        test = report.startTest("Test 1 - Launching Browser");
        // Check browser opened successfully
        if( driver == null){
            Assert.assertNull(driver,"Opening Browser Failed");
        }
        else {
            Assert.assertEquals(driver.getTitle(), "Amazon.co.uk: Low Prices in Electronics, Books, Sports Equipment & more","Test Passed");
        }
        test.log(LogStatus.PASS,"Test1","Browser Opened Successful");
        report.endTest(test);
    }

    //Test 2 - Go to Sign-in page from Home Page and verify the page
    @Test(priority = 2)
    public void goToSignPage(){
        test = report.startTest("Test 2 - Go To Sign-in Page");
        //Goto Sign-in Page
        String accountList_xpath="//a[@id='nav-link-accountList']";
        if (!(checkElement(accountList_xpath)).isDisplayed()) {
            test.log(LogStatus.FAIL,"Account List button Missing");
        } else {
              clickElement(accountList_xpath);
              Assert.assertEquals(driver.getTitle(),"Amazon Sign In","Test2 Success");
              test.log(LogStatus.PASS,"Test2","Sign-in Page Success");
        }
        report.endTest(test);

    }

    // Test 3 - Mouse hover function on Sign-in webelement
    @Test(priority=3)
    public void displaySignInDropDown(){
        test = report.startTest("Test3 - Testing Sign-in Drowndown");
        driver.navigate().back();
        //identify the sign-in dropwdown
        String signInDropDown_xpath="//header/div[@id='navbar']/div[@id='nav-belt']/div[3]/div[1]/a[2]/span[2]/span[1]";
        String SignInButton_xpath="//header/div[@id='navbar']/div[@id='nav-flyout-anchor']/div[@id='nav-flyout-accountList']/div[2]/div[1]/div[1]/div[1]/a[1]/span[1]";
        hoverDropDown(signInDropDown_xpath);
        //mouse hover on the webelement
        selectDropDown(SignInButton_xpath,"Sign In");
        //click sign-in
        clickElement(SignInButton_xpath);
        report.endTest(test);
    }

    @AfterTest
    public void closeAll(){
       // report.endTest(test);
        report.flush();
        closeBrowser();

    }
}
