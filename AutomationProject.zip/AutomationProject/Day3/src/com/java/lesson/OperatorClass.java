package com.java.lesson;
//import java.lang.* ;

public class OperatorClass {
    public static void main(String[] args){
        int x=1 ;
        int y=2;

        int z1 = x + y ; // additional operator
        int z2 = y - x ; // subtraction operator
        int z3 = x * y ; // multiplication
        int z4 = y/x; // Division Operator
        int z5 = y % x ; // Modulus operator

        System.out.println("variable z1= " + z1);
        System.out.println(z2);
        System.out.println(z3);
        System.out.println(z4);
        System.out.println(z5);

        //String Methods inside Java.lang
        String text="Selenium with Java Course - Day 3";
        boolean status = text.endsWith("3");
        boolean result= text.contains("Java1");
        System.out.println("status = " + status);
        System.out.println("result = " + result);
    }



}
