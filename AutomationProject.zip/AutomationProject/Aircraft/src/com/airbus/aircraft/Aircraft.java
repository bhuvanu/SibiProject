package com.airbus.aircraft;

public class Aircraft {

    public Aircraft(String args1){
        System.out.println(args1);
    }
/*
    public Aircraft(){
        System.out.println("Default Constructor");
    }
*/
    private void takeOff(){
        System.out.println("Aircraft is taking off");
    }

    private String landing(int number){
       // int no = number ;
        return("A380 Aircraft Landing " + number);
    }

    public static void main(String[] args){
       // int x = 10;
        Aircraft A380 = new Aircraft("Aircraft Ready");
        A380.takeOff();
        A380.landing(10);
      //  String args2 = A380.landing(x);
      //  System.out.println(args2);
    }
}
