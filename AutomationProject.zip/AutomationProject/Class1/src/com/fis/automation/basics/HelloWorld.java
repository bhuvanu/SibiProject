package com.fis.automation.basics;

public class HelloWorld {
    public static void main (String[] args){
      //  System.out.println("Hello Girls");

        //data types
        String name = "Hello Bhuvan";
       // int number = 10;
        char letter;
        letter = 'B';
        boolean answer = true;
        System.out.println(name);
        System.out.println(letter);
        System.out.println(answer);
    }
}
